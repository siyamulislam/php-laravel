<?php $__env->startSection('body'); ?>
    <div class="maincontent-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="latest-product">
                        <h2 class="section-title">Products</h2>
                        <div class="product-carousel">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-product">
                                <div class="product-f-image">
                                    <img src="<?php echo e(asset($product->image)); ?>" alt="" height="150" width="200">
                                    <div class="product-hover">
                                        <a href="<?php echo e(route('product.website.detail',['id'=>$product->id])); ?>" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                                    </div>
                                </div>

                                <h2><a href="<?php echo e(route('product.website.detail',['id'=>$product->id])); ?>"><?php echo e($product->name); ?></a></h2>

                                <div class="product-carousel-price">
                                    <p><?php echo e($product->category_name); ?></p>
                                    <p><?php echo e($product->brand_name); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End main content area -->

    <div class="brands-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="brand-wrapper">
                        <div class="brand-list">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand1.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand2.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand3.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand4.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand5.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand6.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand1.png" alt="">
                            <img src="<?php echo e(asset('/')); ?>website/img/brand2.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- End brands area -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_61-exam\siyamul_0400036460\resources\views/website/home/index.blade.php ENDPATH**/ ?>