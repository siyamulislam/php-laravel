<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Add product Form</div>
                <div class="card-body">
                    <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                    <form action="<?php echo e(route('product.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Name</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Category Name</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="category_name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Brand Name</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="brand_name">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Description</label>
                            <div class="col-md-9">
                                <textarea type="text" rows="5" class="form-control" name="description"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Image</label>
                            <div class="col-md-9">
                                <input type="file" class="form-control-file" name="image">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3">Publication Status</label>
                            <div class="col-md-9">
                                <label><input type="radio" checked name="status" value="1"/> Published</label>
                                <label><input type="radio" name="status" value="0"/> Unpublished</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-primary" value="Create New Product">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_61-exam\siyamul_0400036460\resources\views/admin/product/index.blade.php ENDPATH**/ ?>