<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">All Product Information</div>
                <div class="card-body">
                    <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>SL No</th>
                            <th>Name</th>
                            <th>Category Name</th>
                            <th>Brand Name</th>
                            <th>Image</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->brand_name); ?></td>
                                <td><img src="<?php echo e(asset($product->image)); ?>" alt="" width="120" height="80"></td>
                                <td><?php echo e($product->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('product.detail',['id'=>$product->id])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-book-open"></i></a>
                                    <a href="<?php echo e(route('product.edit',['id'=>$product->id])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('product.delete',['id'=>$product->id])); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_61-exam\siyamul_0400036460\resources\views/admin/product/manage.blade.php ENDPATH**/ ?>