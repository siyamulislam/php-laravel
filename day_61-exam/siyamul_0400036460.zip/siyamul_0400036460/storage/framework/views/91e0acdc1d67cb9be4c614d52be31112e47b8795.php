<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Product Detail Information</div>
                <div class="card-body">
                    <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($product->name); ?></td>
                        </tr>
                        <tr>
                            <th>Category Name</th>
                            <td><?php echo e($product->category_name); ?></td>
                        </tr>
                        <tr>
                            <th>Brand Name</th>
                            <td><?php echo e($product->brand_name); ?></td>
                        </tr>
                        <tr>
                            <th>Description</th>
                            <td><?php echo e($product->description); ?></td>
                        </tr>
                        <tr>
                            <th>Image</th>
                            <td><img src="<?php echo e(asset($product->image)); ?>" height="100" width="120" alt=""></td>
                        </tr>
                        <tr>
                            <th>Publication Status</th>
                            <td><?php echo e($product->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_61-exam\siyamul_0400036460\resources\views/admin/product/detail.blade.php ENDPATH**/ ?>