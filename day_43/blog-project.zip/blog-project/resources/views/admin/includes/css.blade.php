<!-- App favicon -->
<link rel="shortcut icon" href="{{asset('/')}}admin/assets/images/favicon.ico">

<!-- third party css -->
<link href="{{asset('/')}}admin/assets/css/vendor/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css"/>
<!-- third party css end -->

<!-- Datatables css -->
<link href="{{asset('/')}}admin/assets/css/vendor/dataTables.bootstrap5.css" rel="stylesheet" type="text/css" />
<link href="{{asset('/')}}admin/assets/css/vendor/responsive.bootstrap5.css" rel="stylesheet" type="text/css" />

<!-- App css -->
<link href="{{asset('/')}}admin/assets/css/icons.min.css" rel="stylesheet" type="text/css"/>
<link href="{{asset('/')}}admin/assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>


