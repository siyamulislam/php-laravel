
<?php $__env->startSection('title'); ?> Dashboard |  Product Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container">
        <div class="row py-3">
            <div class="col-md-4 ">
                <img src="<?php echo e(asset( $product->image)); ?>" class="rounded " width="100%" alt="...">
                <a href="<?php echo e(route('product.edit', ['id'=>$product->id])); ?>

                    " class="btn btn-primary btn w-100 my-2">Edit</a>
                <a href="<?php echo e(route('product.delete', ['id'=>$product->id])); ?>"
                   onclick="return confirm('Are you sure to delete this ?')"
                   class="btn btn-danger btn w-100">Delete</a>
            </div>

            <div class="col-md-5">
                <h2 class=""> <?php echo e($product->name); ?></h2>

                <small class="text-info" >  Brand: <?php echo e($product->brand['name']); ?>

                    | Category: <?php echo e($product->category['name']); ?>

                </small> <br>
                <small>  Status: <?php echo e($product->status=1?"Published":"Unpublished"); ?>

                    | <?php echo e($product->lastUpdate.' ago'); ?>

                </small><br>
                <h3  class="pt-3 text-danger" ><sup class=" text-muted">Price:</sup> ৳ <?php echo e($product->price); ?></h3>
                <p><del>৳ <?php echo e($product->price*2); ?></del>-50% discount</p>
                <hr class="text-muted">
                <h4>Product Description</h4>
                <hr class="text-muted">
                <p ></p>
                <div class="lh-base" style="text-align: justify;">
                    <?php echo $product->description; ?>

                </div>

            </div>
            <div class="col-md-3">
                <h3 class="text-secondary">Sold by: <?php echo e($product->brand['name']); ?> </h3>

                <hr class="text-muted">
                <h4>Ratings & Reviews</h4>
                <hr class="text-muted">
                <p >4.7/5(1275) *</p>


            </div>
        </div>
        <hr class="text-muted">
        <div class="row py-2">
            <div class="col-md-1 mx-auto">
            </div>
            <div class="col-md-9 mx-auto">
                <h4>Product Description</h4>
                <hr class="text-muted">
                <p class="lh-lg" style="text-align: justify;"> <?php echo $product->description; ?></p>

            </div>
            <div class="col-md-2 mx-auto">

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\php-laravel\day_43\blog-project\resources\views/admin/product/details.blade.php ENDPATH**/ ?>