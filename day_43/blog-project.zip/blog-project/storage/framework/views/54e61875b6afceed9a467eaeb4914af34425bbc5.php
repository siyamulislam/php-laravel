
<?php $__env->startSection('title'); ?> Dashboard |  Category Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="container">
        <div class="row py-3">
            <div class="col-md-6 pe-5">
                <h2 class="">Title: <?php echo e($category->name); ?></h2>
                <small>  Status: <?php echo e($category->status=1?"Published":"Unpublished"); ?>

                || Created at: <?php echo e($category->created_at); ?>

                </small>
                <hr class="text-muted">
                <h4>Category Description</h4>
                <hr class="text-muted">
                <p class="lh-base" style="text-align: justify;"><?php echo e($category->description); ?></p>
            </div>
            <div class="col-md-6">
                <img src="<?php echo e(asset( $category->image)); ?>" class="rounded " width="100%" alt="...">
                <a href="<?php echo e(route('category.edit', ['id'=>$category->id])); ?>

                    " class="btn btn-primary btn w-100 my-2">Edit</a>
                <a href="<?php echo e(route('category.delete', ['id'=>$category->id])); ?>"
                   onclick="return confirm('Are you sure to delete this ?')"
                   class="btn btn-danger btn w-100">Delete</a>
            </div>
        </div>
        <div class="row py-5">
            <div class="col-md-1 mx-auto">
            </div>
            <div class="col-md-7 mx-auto">
                

            </div>
            
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\php-laravel\day_43\blog-project\resources\views/admin/category/details.blade.php ENDPATH**/ ?>