
<!-- bundle -->
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/app.min.js"></script>

<!-- third party js -->
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/apexcharts.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/jquery-jvectormap-world-mill-en.js"></script>
<!-- third party js ends -->

<!-- Datatables js -->
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/dataTables.bootstrap5.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/assets/js/vendor/responsive.bootstrap5.min.js"></script>

<!-- Datatable Init js -->
<script src="<?php echo e(asset('/')); ?>admin/assets/js/pages/demo.datatable-init.js"></script>

<!-- demo app -->
<script src="<?php echo e(asset('/')); ?>admin/assets/js/pages/demo.dashboard.js"></script>
<!-- end demo js-->
<!--ck-edit-->
<script src="https://cdn.ckeditor.com/4.20.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'product_description' );
</script>
<?php /**PATH E:\xampp\htdocs\php-laravel\day_43\blog-project\resources\views/admin/includes/js.blade.php ENDPATH**/ ?>