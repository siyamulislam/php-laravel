
<?php $__env->startSection('title'); ?> Dashboard | Manage Brand <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-11 mx-auto">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class=" fw-normal display-6 text-secondary text-center">Manage Brand</div>
                    </div>
                </div>
                <div class="card-body">
                    <p class="text-success text-center"><?php echo e(Session::has('success') ? Session::get('success') :""); ?></p>
                    <p class="text-danger text-center"><?php echo e(Session::has('delete') ?Session::get('delete'):""); ?></p>
                    
                    <table id="basic-datatable" class="table dt-responsive nowrap w-100" >
                        <thead>
                        <tr>
                            <th>Sl</th>
                            <th style="width:10%">Image</th>
                            <th>Brand Title</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th style="width:30%">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  class="<?php echo e($brand->status == 1 ? '' : 'bg-secondary text-light'); ?>"   >
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img src="<?php echo e(asset($brand->image)); ?>" alt="" height="50" width="70"></td>
                                <td><?php echo e($brand->name); ?></td>
                                <td><?php echo e(Illuminate\Support\Str::limit($brand->description,30, '...')); ?></td>
                                <td><?php echo e($brand->status==1?"Published":"Unpublished"); ?></td>
                                <td>
                                    <a href="<?php echo e(route('brand.details', ['id'=>$brand->id])); ?>"
                                       class="btn btn-success btn-sm">Details</a>
                                    <a href="<?php echo e(route('brand.edit', ['id'=>$brand->id])); ?>"
                                       class="btn btn-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(route('brand.delete', ['id'=>$brand->id])); ?>"
                                       onclick="return confirm('Are you sure to delete this ?')"
                                       class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\php-laravel\day_43\blog-project\resources\views/admin/brand/manage.blade.php ENDPATH**/ ?>