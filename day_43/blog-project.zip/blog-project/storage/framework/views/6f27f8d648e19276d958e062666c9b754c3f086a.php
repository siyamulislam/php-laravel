
<?php $__env->startSection('title'); ?> Dashboard | Manage Product <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12 mx-auto">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class=" fw-normal display-6 text-secondary text-center">Manage Product</div>
                    </div>
                </div>
                <div class="card-body">
                    <p class="text-success text-center"><?php echo e(Session::has('success') ? Session::get('success') :""); ?></p>
                    <p class="text-danger text-center"><?php echo e(Session::has('delete') ?Session::get('delete'):""); ?></p>
                    

                    <table id="basic-datatable" class="table dt-responsive nowrap table-bordered  w-100"  >
                        <thead>
                        <tr>
                            <th>Sl</th>
                            <th >Image</th>
                            <th >Product Title</th>
                            <th >Category</th>
                            <th >Brand</th>
                            <th >Price</th>
                            <th >Status</th>
                            <th >Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  valign="middle" class="<?php echo e($product->status == 1 ? '' : 'bg-secondary text-light'); ?>">

                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img src="<?php echo e(asset($product->image)); ?>" alt="" height="50" width="50"></td>
                                <td><?php echo e(\Illuminate\Support\Str::words($product->name,2,'...')); ?></td>
                                <td><?php echo e($product->category['name']); ?></td>
                                <td><?php echo e($product->brand['name']); ?></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->status==1?"Published":"Unpublished"); ?></td>
                                <td>
                                    <a href="<?php echo e(route('product.details', ['id'=>$product->id])); ?>"
                                       class="btn btn-success btn-sm">Details</a>
                                    <a href="<?php echo e(route('product.edit', ['id'=>$product->id])); ?>"
                                       class="btn btn-primary btn-sm">Edit</a>
                                    <a href="<?php echo e(route('product.delete', ['id'=>$product->id])); ?>"
                                       onclick="return confirm('Are you sure to delete this ?')"
                                       class="btn btn-danger btn-sm">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\php-laravel\day_43\blog-project\resources\views/admin/product/manage.blade.php ENDPATH**/ ?>