
<?php $__env->startSection('title'); ?>
    Add Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card bg-dark text-white">
                        <div class="card-header  ">
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-9">
                                    <div class="card-header fw-bold display-6 text-info">Add Blog</div>
                                </div>
                            </div>

                        </div>
                        <div class="card-body">
                            <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                            <form action="<?php echo e(route('blog.update', ['id'=>$blog->id])); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <label class="col-md-3"> Category Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="category_id">

                                            <option value="<?php echo e($blog->category_id); ?>"><?php echo e($categories[--$blog->category_id]->name); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-md-3"> Blog Title</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php echo e($blog->title); ?>" name="title">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label for="">Short Description</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control"value="<?php echo e($blog->short_description); ?>" name="short_description">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label for="">Long Description</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php echo e($blog->long_description); ?>" name="long_description">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label for="">Image</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image">
                                        <img src="<?php echo e(asset($blog->image)); ?>" alt="" height="50" width="70">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-3">
                                        <label for=""></label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="submit" class="btn btn-outline-info" value="Update Blog">
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_35\blog-app\resources\views/blog/edit.blade.php ENDPATH**/ ?>