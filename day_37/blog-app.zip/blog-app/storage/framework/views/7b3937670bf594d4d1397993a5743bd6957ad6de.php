<?php $__env->startSection('title'); ?>
   Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row">
                <?php foreach ($blogs as $blog) { ?>
                <div class="col-md-3">
                    <div class="card bg-dark text-white mb-3">
                        <img src="<?php echo $blog['image']?>" alt="" height="250" class="card-img">
                        <div class="card-body">
                            <h6><?php echo $blog['title']?></h6>
                            <h6>Category: <?php echo $blog['category_id']?></h6>

                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_37\blog-app\resources\views/home/index.blade.php ENDPATH**/ ?>