<?php $__env->startSection('title'); ?>
    <?php echo e($blog->title); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    <section class="py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <div class="card" style=" ">
                        <img src="<?php echo e(asset($blog->image)); ?>" class="card-img-top h-450" alt="...">
                        <div class="card-body">
                            <h2 class="card-title"> <?php echo e($blog->title); ?></h2>
                            <small class="card-title fw-normal text-muted">Category: <?php echo e($categories[--$blog->category_id]->name); ?>

                             | View: <?php echo e($blog->hit_count); ?>

                                | Status: <?php echo e($blog->status=1?"Published":"Unpublished"); ?>

                                | posted on: <?php echo e($blog->	created_at); ?>

                                | Last update at: <?php echo e($blog->	updated_at); ?>

                            </small>
                            <hr class="text-muted">
                            <p class="card-text"><?php echo e($blog->short_description); ?></p>
                            <br>
                            <p class="card-text"><?php echo e($blog->long_description); ?></p>
                                <a href="<?php echo e(route('blog.edit', ['id'=>$blog->id])); ?>" class="btn btn-primary btn w-100 mb-2">Edit</a>
                                <a href="<?php echo e(route('blog.delete', ['id'=>$blog->id])); ?>"
                                   onclick="return confirm('Are you sure to delete this ?')"
                                   class="btn btn-danger btn w-100">Delete</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_37\blog-app\resources\views/blog/detail.blade.php ENDPATH**/ ?>