<?php $__env->startSection('title'); ?>
    Manage Blogs
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <div class="card bg-dark text-white">
                        <div class="card-header">
                            <div class="row">
                                <div class="card-header fw-bold display-6 text-info text-center">Manage Blog</div>
                            </div>
                        </div>
                        <div class="card-body">
                            <p class="text-success text-center"><?php echo e(Session::get('message')); ?></p>
                            <p class="text-danger text-center"><?php echo e(Session::get('message_delete')); ?></p>
                            <table class="table table-bordered table-hover table-dark  table-striped">
                                <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Short Description</th>
                                    <th style="width:8%">Image</th>
                                    <th  >Status</th>
                                    <th style="width:20%">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>

                                        <td><?php echo e($blog->category['name']); ?></td>
                                        <td><?php echo e(substr( $blog->title , 0, 15).'..'); ?></td>
                                        <td ><?php echo e(substr( $blog->short_description,  0,35).'..'); ?></td>
                                        <td><img src="<?php echo e(asset($blog->image)); ?>" alt="" height="50" width="70"></td>
                                        <td  ><?php echo e($blog->status=1?"Published":"Unpublished"); ?></td>

                                        <td >
                                            <a href="<?php echo e(route('blog.detail', ['id'=>$blog->id])); ?>" class="btn btn-success btn-sm">Details</a>
                                            <a href="<?php echo e(route('blog.edit', ['id'=>$blog->id])); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <a href="<?php echo e(route('blog.delete', ['id'=>$blog->id])); ?>" onclick="return confirm('Are you sure to delete this ?')" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_35\blog-app\resources\views/blog/manage.blade.php ENDPATH**/ ?>