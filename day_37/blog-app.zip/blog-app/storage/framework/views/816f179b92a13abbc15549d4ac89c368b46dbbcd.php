<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/fontawesome/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>assets/css/style.css">
</head>
<body>
<?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>;
<script src="<?php echo e(asset('/')); ?>assets/js/bootstrap.bundle.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/js/jquery-3.6.1.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\workDB\php-laravel\day_35\blog-app\resources\views/master.blade.php ENDPATH**/ ?>